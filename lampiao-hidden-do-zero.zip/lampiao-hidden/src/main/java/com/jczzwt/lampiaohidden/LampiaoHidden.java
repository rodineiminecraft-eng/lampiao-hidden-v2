package com.jczzwt.lampiaohidden;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

public class LampiaoHidden implements ModInitializer {
    private static final String LAMP_NAME = "Lampião Lendário";

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                updatePlayer(player);
            }
        });
    }

    private static void updatePlayer(ServerPlayerEntity player) {
        boolean holding = isLampiao(player.getMainHandStack()) || isLampiao(player.getOffHandStack());
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.INVISIBILITY);

        if (holding) {
            // Short refresh prevents gaps while keeping the effect effectively permanent.
            if (current == null || current.getDuration() < 40 || !current.isAmbient()) {
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.INVISIBILITY,
                        80,
                        0,
                        true,
                        false,
                        false
                ));
            }
        } else if (current != null && current.isAmbient()) {
            player.removeStatusEffect(StatusEffects.INVISIBILITY);
        }
    }

    private static boolean isLampiao(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.LANTERN)) return false;
        if (!stack.contains(DataComponentTypes.CUSTOM_NAME)) return false;
        return stack.getName().getString().equals(LAMP_NAME);
    }
}
