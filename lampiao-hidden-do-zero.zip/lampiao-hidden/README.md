# Lampião Hidden

Mod Fabric server-side para Minecraft 1.21.11.

## O que faz
- Detecta o **Lampião Lendário** na mão principal ou secundária.
- Deixa **somente o jogador que está segurando o lampião** invisível.
- A invisibilidade é renovada automaticamente enquanto o lampião estiver na mão.
- Ao guardar/trocar o lampião, a invisibilidade criada pelo mod é removida.

## Importante
O reconhecimento usa uma **lanterna (`minecraft:lantern`) com o nome exato `Lampião Lendário`**. Para entregar o item:

```mcfunction
/give @p minecraft:lantern[custom_name='{"text":"Lampião Lendário","italic":false}']
```

## Compilar no GitHub
O projeto inclui um workflow em `.github/workflows/build.yml`. Depois de enviar os arquivos ao GitHub, abra **Actions → Compilar Lampião Hidden → Run workflow**.
